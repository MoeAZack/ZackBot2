from pathlib import Path
import json,hashlib,urllib.request,urllib.parse,concurrent.futures
from datetime import datetime
from zoneinfo import ZoneInfo
import pandas as pd,numpy as np
R=Path('F:/ZackBot2_data/C1H-VENUE-RECHECK-20261112');diff=json.loads((R/'remaining_differences.json').read_text());pairs=sorted({(x['symbol'],x['t']) for x in diff});authority=json.loads((R/'data_authority_contract.json').read_text());authority['pre_economic_conflict_rule_amendment']={'at_cairo':datetime.now(ZoneInfo('Africa/Cairo')).isoformat(),'rule':'Resolve EVERY OHLCV disagreement over rtol1e-8/atol1e-8 between checksum archives and original frozen research data via same current public futures REST endpoint, irrespective of signal, trade, P&L or which source it favors. Preserve all responses and replacements. No candidate/economic rerun occurred before this amendment.','requests':len(pairs)};(R/'data_authority_contract.json').write_text(json.dumps(authority,indent=2))
def fetch(pair):
 sym,label=pair;t=pd.Timestamp(label,tz='UTC');start=int(t.timestamp()*1000);url='https://fapi.binance.com/fapi/v1/klines?'+urllib.parse.urlencode({'symbol':sym,'interval':'1h','startTime':start,'limit':1});raw=urllib.request.urlopen(url,timeout=20).read();rows=json.loads(raw);assert isinstance(rows,list) and len(rows)==1 and int(rows[0][0])==start
 p=R/'rest_responses'/(sym+'-'+t.strftime('%Y%m%dT%H%M%S')+'-conflict.json');p.write_bytes(raw);return pair,rows[0],{'url':url,'response_file':str(p),'sha256':hashlib.sha256(raw).hexdigest()}
resolved={};requests=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 for pair,row,meta in ex.map(fetch,pairs):resolved[pair]=row;requests.append(meta)
changes=[];manifest=json.loads((R/'input_manifest.json').read_text())
for ds,syms in manifest.items():
 for sym,info in syms.items():
  p=R/'inputs'/ds/(sym+'.csv');d=pd.read_csv(p,parse_dates=['t'])
  for (symbol,label),x in resolved.items():
   if symbol!=sym:continue
   idx=d.index[d.t==pd.Timestamp(label)]
   if not len(idx):continue
   assert len(idx)==1;i=idx[0];new={'o':x[1],'h':x[2],'l':x[3],'c':x[4],'v':x[5],'qv':x[7],'trades':x[8],'tbqv':x[10],'tbv':x[9]};before=d.loc[i,list(new)].to_dict()
   for k,v in new.items():d.loc[i,k]=float(v)
   changes.append({'dataset':ds,'symbol':sym,'time_utc':label,'previous':before,'canonical_rest':new})
  assert d.t.is_unique and d.t.diff().iloc[1:].eq(pd.Timedelta(hours=1)).all();assert np.isfinite(d.drop(columns='t').to_numpy()).all();assert (d.tbqv<=d.qv+1e-7).all();d.to_csv(p,index=False);info['input_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
(R/'input_manifest.json').write_text(json.dumps(manifest,indent=2));(R/'rest_conflict_resolution.json').write_text(json.dumps({'requests':requests,'rows_reconciled':changes},indent=2,default=str));(R/'data_ready.json').write_text(json.dumps({'status':'CANONICAL_DATA_FROZEN','at_cairo':datetime.now(ZoneInfo('Africa/Cairo')).isoformat(),'dataset_files':sum(len(x) for x in manifest.values()),'manifest_sha256':hashlib.sha256((R/'input_manifest.json').read_bytes()).hexdigest(),'unresolved_source_conflicts':0},indent=2));print('canonical REST conflicts resolved',len(pairs),'rowsreconciled',len(changes))