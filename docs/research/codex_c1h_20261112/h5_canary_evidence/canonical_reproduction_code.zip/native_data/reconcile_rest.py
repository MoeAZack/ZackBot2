from pathlib import Path
import json,hashlib,urllib.request,urllib.parse,concurrent.futures,shutil
from datetime import datetime
from zoneinfo import ZoneInfo
import pandas as pd,numpy as np
S=Path('F:/ZackBot2_data/C1H-NATIVE-DATA-20261112');R=Path('F:/ZackBot2_data/C1H-VENUE-RECHECK-20261112');R.mkdir(exist_ok=True);(R/'rest_responses').mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
quality=json.loads((S/'data_quality.json').read_text());contract={'frozen_cairo':datetime.now(ZoneInfo('Africa/Cairo')).isoformat(),'authority_rule':'Published checksum-verified official monthly archives as baseline; EVERY zero-volume/flat-OHLC anomaly and its immediately neighboring hours is reconciled with current public futures REST klines, all fields replaced by returned REST records, no selection by P&L. Preserve archives, response bytes, URLs, before/after and hashes. No missing REST fallback.','source_manifest_sha256':sha(S/'input_manifest.json'),'no_candidate_parameter_change':True}
(R/'data_authority_contract.json').write_text(json.dumps(contract,indent=2))
requests={}
for ds,syms in quality.items():
 for sym,v in syms.items():
  for t in v['zero_volume_flat_timestamps_utc']:requests[(sym,t)]=pd.Timestamp(t,tz='UTC')
def fetch(item):
 (sym,label),t=item;start=int((t-pd.Timedelta(hours=1)).timestamp()*1000);params={'symbol':sym,'interval':'1h','startTime':start,'limit':3};url='https://fapi.binance.com/fapi/v1/klines?'+urllib.parse.urlencode(params);raw=urllib.request.urlopen(url,timeout=20).read();rows=json.loads(raw);assert isinstance(rows,list) and len(rows)==3;assert [int(x[0]) for x in rows]==[start+i*3600000 for i in range(3)]
 name=sym+'-'+t.strftime('%Y%m%dT%H%M%S');p=R/'rest_responses'/(name+'.json');p.write_bytes(raw)
 return sym,rows,{'symbol':sym,'anomaly_utc':t.isoformat(),'url':url,'response_sha256':sha(p),'response_file':str(p)}
responses={};provenance=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 for sym,rows,meta in ex.map(fetch,requests.items()):
  responses.setdefault(sym,{}).update({pd.Timestamp(int(x[0]),unit='ms'):x for x in rows});provenance.append(meta)
manifest={};changes=[];comparisons={}
for ds in ['cohort9_1h','long8_1h']:
 out=R/'inputs'/ds;out.mkdir(parents=True,exist_ok=True);manifest[ds]={};comparisons[ds]={}
 for p in sorted((S/'inputs'/ds).glob('*.csv')):
  d=pd.read_csv(p,parse_dates=['t']);sym=p.stem
  for t,x in responses[sym].items():
   idx=d.index[d.t==t];assert len(idx)==1;i=idx[0];new={'o':x[1],'h':x[2],'l':x[3],'c':x[4],'v':x[5],'qv':x[7],'trades':x[8],'tbqv':x[10],'tbv':x[9]};before=d.loc[i,list(new)].to_dict()
   for k,v in new.items():d.loc[i,k]=float(v)
   changes.append({'dataset':ds,'symbol':sym,'time_utc':t.isoformat(),'archive':before,'rest':new})
  assert d.t.is_unique and d.t.diff().iloc[1:].eq(pd.Timedelta(hours=1)).all();assert np.isfinite(d.drop(columns='t').to_numpy()).all();assert (d[['o','h','l','c']]>0).all().all();assert (d.tbqv<=d.qv+1e-7).all() and (d.tbv<=d.v+1e-7).all()
  dest=out/p.name;d.to_csv(dest,index=False);manifest[ds][sym]={'input_sha256':sha(dest),'source_archive_manifest_sha256':sha(S/'input_manifest.json'),'rows':len(d),'first_candle_utc':d.t.iloc[0].isoformat(),'last_candle_utc':d.t.iloc[-1].isoformat(),'rest_response_files':[v['response_file'] for v in provenance if v['symbol']==sym]}
  old=pd.read_csv(Path('F:/ZackBot2_data/C1H-20261112/inputs')/ds/p.name,parse_dates=['t']);assert old.t.equals(d.t)
  comparisons[ds][sym]={k:{'outside_tolerance':int((~np.isclose(d[k],old[k],rtol=1e-8,atol=1e-8)).sum()),'max_abs':float((d[k]-old[k]).abs().max())} for k in ['o','h','l','c','v']}
(R/'input_manifest.json').write_text(json.dumps(manifest,indent=2));(R/'rest_repairs.json').write_text(json.dumps({'source_requests':provenance,'rows_reconciled':changes},indent=2,default=str));(R/'original_comparison.json').write_text(json.dumps(comparisons,indent=2));print(json.dumps({'REST_queries':len(provenance),'reconciled_rows':len(changes),'datasets':{k:len(v) for k,v in manifest.items()},'remaining_price_volume_mismatches_to_old':{ds:sum(v['outside_tolerance'] for m in sy.values() for v in m.values()) for ds,sy in comparisons.items()}}))