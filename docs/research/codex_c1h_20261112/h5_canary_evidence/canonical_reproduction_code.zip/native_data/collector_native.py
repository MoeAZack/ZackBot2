import csv,datetime as D,hashlib,io,json,os,re,time,urllib.request,urllib.error,zipfile,concurrent.futures,shutil
from decimal import Decimal
from pathlib import Path
R=Path(r'F:\ZackBot2_data\C1H-NATIVE-DATA-20261112'); OLD=Path(r'F:\ZackBot2_data\C1H-20261112'); BASE='https://data.binance.vision/data/futures/um/monthly/klines'; orig=json.loads((OLD/'input_manifest.json').read_text()); m={'status':'running','cohorts':{},'archives':{},'errors':[]}; s={'status':'running','phase':None,'archives_completed':0,'errors':[]}
def save():
 for n,x in [('input_manifest.json',m),('status.json',s)]:
  p=R/n; q=p.with_suffix('.tmp'); q.write_text(json.dumps(x,indent=2)); os.replace(q,p)
def sha(b): return hashlib.sha256(b).hexdigest()
def get(url,cap):
 for i in range(3):
  try:
   with urllib.request.urlopen(url,timeout=20) as f:
    b=f.read(cap+1)
    if len(b)>cap: raise ValueError('size cap '+url)
    return b
  except (urllib.error.URLError,TimeoutError,ConnectionError,OSError) as e:
   if isinstance(e,urllib.error.HTTPError) and e.code not in (408,429,500,502,503,504): raise
   if i==2: raise
   time.sleep(i+1)
def months(a,b):
 y,n=a.year,a.month
 while (y,n)<=(b.year,b.month):
  yield f'{y:04d}-{n:02d}'; n+=1
  if n==13: y+=1; n=1
def archive(sym,month):
 name=f'{sym}-1h-{month}.zip'; url=f'{BASE}/{sym}/1h/{name}'; p=R/'archives'/name; c=Path(str(p)+'.CHECKSUM'); pilot=Path(r'F:\ZackBot2_data\C1H-FLOW-20261112')
 if name=='BTCUSDT-1h-2024-10.zip' and not p.exists() and (pilot/name).exists() and (pilot/(name+'.CHECKSUM')).exists(): shutil.copyfile(pilot/name,p); shutil.copyfile(pilot/(name+'.CHECKSUM'),c)
 cb=c.read_bytes() if c.exists() else get(url+'.CHECKSUM',4096); match=re.fullmatch(r'\s*([0-9a-fA-F]{64})\s+\*?([^\s]+)\s*',cb.decode('ascii'))
 if not match or match.group(2)!=name: raise ValueError('invalid checksum '+name)
 b=p.read_bytes() if p.exists() else get(url,5000000)
 if len(b)>5000000 or sha(b)!=match.group(1).lower(): raise ValueError('checksum/size failure '+name)
 with zipfile.ZipFile(io.BytesIO(b)) as z:
  inf=z.infolist()
  if len(inf)!=1 or inf[0].is_dir() or not inf[0].filename.endswith('.csv') or inf[0].file_size>20000000: raise ValueError('invalid zip '+name)
  if len(z.read(inf[0]))>20000000: raise ValueError('uncompressed cap '+name)
 p.write_bytes(b); c.write_bytes(cb)
 return name,{'url':url,'checksum_url':url+'.CHECKSUM','published_sha256':match.group(1).lower(),'archive_sha256':sha(b),'compressed_bytes':len(b),'uncompressed_bytes':inf[0].file_size,'status':'verified'}
def build(cohort,sym,e):
 start=D.datetime.fromisoformat(e['first_candle_utc']); end=D.datetime.fromisoformat(e['last_candle_utc']); first=int(start.replace(tzinfo=D.timezone.utc).timestamp()*1000); last=int(end.replace(tzinfo=D.timezone.utc).timestamp()*1000); rows=[]; fields=['t','o','h','l','c','v','qv','trades','tbqv','tbv']
 for month in months(start,end):
  name=f'{sym}-1h-{month}.zip'
  if name not in m['archives']: raise ValueError('missing verified archive '+name)
  with zipfile.ZipFile(R/'archives'/name) as z, z.open(z.infolist()[0]) as f:
   for r in csv.reader(io.TextIOWrapper(f,encoding='utf-8',newline='')):
    if r and r[0]=='open_time': continue
    if len(r)!=12: raise ValueError('invalid field count '+name)
    t=int(r[0]); ct=int(r[6])
    if t<first or t>last: continue
    if ct!=t+3599999: raise ValueError('close time '+name)
    o,h,l,c,v,qv,tbv,tbqv=map(Decimal,[r[1],r[2],r[3],r[4],r[5],r[7],r[9],r[10]])
    if not all(x.is_finite() for x in (o,h,l,c,v,qv,tbv,tbqv)) or min(o,h,l,c)<=0 or min(v,qv,tbv,tbqv)<0 or h<max(o,c,l) or l>min(o,c,h): raise ValueError('invalid OHLCV '+name+' '+str(t))
    if tbv>v+max(Decimal('1e-8'),abs(v)*Decimal('1e-10')) or tbqv>qv+max(Decimal('1e-8'),abs(qv)*Decimal('1e-10')) or not re.fullmatch(r'\d+',r[8]): raise ValueError('invalid volume/trades '+name)
    rows.append((t,[D.datetime.fromtimestamp(t/1000,D.timezone.utc).strftime('%Y-%m-%d %H:%M:%S'),r[1],r[2],r[3],r[4],r[5],r[7],r[8],r[10],r[9]]))
 if len(rows)!=e['rows'] or any(t!=first+i*3600000 for i,(t,_) in enumerate(rows)) or rows[-1][0]!=last: raise ValueError(f'missing/duplicate/unordered timestamps count={len(rows)}')
 out=R/'inputs'/cohort/(sym+'.csv'); out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f,lineterminator='\n'); w.writerow(fields); w.writerows(row for _,row in rows)
 old=OLD/'inputs'/cohort/(sym+'.csv'); comp={'source':str(old),'fields':{k:{'different':0,'max_absolute_error':0.0} for k in ['o','h','l','c','v','qv']},'rows_compared':0,'timestamp_mismatches':0}
 with old.open(newline='',encoding='utf-8') as f:
  for i,r in enumerate(csv.DictReader(f)):
   if i>=len(rows): raise ValueError('original extra rows')
   native=dict(zip(fields,rows[i][1])); comp['rows_compared']+=1
   try: ot=D.datetime.fromisoformat(r['t'].replace('Z','+00:00')).replace(tzinfo=None)
   except Exception: comp['timestamp_mismatches']+=1; continue
   if ot!=start+D.timedelta(hours=i): comp['timestamp_mismatches']+=1; continue
   for k in comp['fields']:
    if k not in r or not r[k]: continue
    d=abs(Decimal(r[k])-Decimal(native[k]))
    if d: comp['fields'][k]['different']+=1; comp['fields'][k]['max_absolute_error']=max(comp['fields'][k]['max_absolute_error'],float(d))
 if comp['rows_compared']!=e['rows']: raise ValueError('original row count mismatch')
 return {'status':'complete','rows':len(rows),'first_candle_utc':e['first_candle_utc'],'last_candle_utc':e['last_candle_utc'],'sha256':sha(out.read_bytes()),'path':str(out),'original_comparison':comp}
def main():
 (R/'archives').mkdir(parents=True,exist_ok=True); save()
 for cohort in ['cohort9_1h','long8_1h']:
  s['phase']=cohort; m['cohorts'][cohort]={'status':'running','symbols':{}}; save(); todo=[]
  for sym,e in orig[cohort].items():
   for month in months(D.datetime.fromisoformat(e['first_candle_utc']),D.datetime.fromisoformat(e['last_candle_utc'])):
    if f'{sym}-1h-{month}.zip' not in m['archives']: todo.append((sym,month))
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
   fs={ex.submit(archive,*x):x for x in todo}
   for f in concurrent.futures.as_completed(fs):
    sym,month=fs[f]
    try: name,record=f.result(); m['archives'][name]=record; s['archives_completed']+=1
    except Exception as e: msg=f'{sym} {month}: {type(e).__name__}: {e}'; s['errors'].append(msg); m['errors'].append(msg); print('ERROR',msg,flush=True)
    if s['archives_completed']%10==0: print(cohort,'verified',s['archives_completed'],'errors',len(s['errors']),flush=True)
    save()
  for sym,e in orig[cohort].items():
   try: m['cohorts'][cohort]['symbols'][sym]=build(cohort,sym,e); print('BUILT',cohort,sym,flush=True)
   except Exception as x: msg=f'{cohort} {sym}: {type(x).__name__}: {x}'; m['errors'].append(msg); s['errors'].append(msg); m['cohorts'][cohort]['symbols'][sym]={'status':'blocked','error':msg}; print('ERROR',msg,flush=True)
   save()
  m['cohorts'][cohort]['status']='complete' if all(x['status']=='complete' for x in m['cohorts'][cohort]['symbols'].values()) else 'partial_blocked'; s[cohort]=m['cohorts'][cohort]['status']; save(); print('PHASE',cohort,s[cohort],flush=True)
 s['status']=m['status']='complete' if all(m['cohorts'][x]['status']=='complete' for x in ['cohort9_1h','long8_1h']) else 'partial_blocked'; save()
if __name__=='__main__':
 try: main()
 except Exception as e: s['status']=m['status']='failed'; s['errors'].append(repr(e)); m['errors'].append(repr(e)); save(); raise
